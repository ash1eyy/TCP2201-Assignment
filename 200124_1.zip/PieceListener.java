import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

//for pieces on the board only
public class PieceListener implements ActionListener {
    private PieceButton[][] buttons;
    private Color validMove = new Color(100, 255, 0);

    PieceListener(PieceButton[][] buttons) {
        this.buttons = buttons;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                buttons[i][j].setBackground(null);
            }
        }
        PieceButton clickedButton = (PieceButton) e.getSource(); //gets the button that was clicked
        
        //only selects the button if there is a piece on it AND it is the user's first time selecting a piece
        if (clickedButton.getSelected() == false &&
            clickedButton.getIcon() != null &&
            clickedButton.getBackground() == null) {

            clickedButton.setSelected(true);
            clickedButton.setBackground(new Color(255,255,153));
        }
        else if (clickedButton.getIcon() == null) {
            
        }

        //highlight valid tiles
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                if (clickedButton.getPiece().isValidMove(GameController.getBoard(), j, i)) {
                    PieceButton validMoveButton = buttons[i][j];
                    validMoveButton.setBackground(validMove);
                }
            }
        }

        //for (int i = 0; i < )
        //on the next click, move the piece to the selected tile (if valid)
    }
}
