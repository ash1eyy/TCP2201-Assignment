import javax.swing.*;//imports 
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameView extends JFrame { // zaf and thash doing this, hello

    public GameView() {
        super("Talabia Chess");
        JPanel panel = new JPanel();

        // default size for board
        setSize(500, 500);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // make the window resizeable
        setResizable(true);

        addGameBoard(); // adds the gameboard into GUI

        addControlPanel();// adds the Control Into GUI

        setVisible(true);// make frame visible
    }

    // add components
    public void addGameBoard() {
        JPanel boardPanel = new JPanel();
        boardPanel.add(new JLabel("Game Board Here")); // this replace with an actual game board
        add(boardPanel, BorderLayout.CENTER); // add to the center of the frame

        GridLayout grid = new GridLayout();
        boardPanel.setLayout(grid);

        for (int i = 0; i < getMap().getY(); i++) {
            for (int j = 0; j < getMap().getX(); j++) { 

                Piece.getMap().getY(i).get(j);//???? gn
            }

        }

    }

    public void addControlPanel() {
        JPanel controlPanel = new JPanel();
        add(controlPanel);

        JButton startButton = new JButton("Start");
        controlPanel.add(startButton);
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO
            }
        });

        JButton saveButton = new JButton("Save");
        controlPanel.add(saveButton);
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // prompts the user to input a filename
            }
        });

        JButton exitButton = new JButton("Exit");
        controlPanel.add(exitButton);
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Game.exit();
            }
        });
    }
}

// DEFINING PIECEs
// Icon HourglassIcon = new ImageIcon(".png file");
// Icon PlusIcon = new ImageIcon(".png file");
// Icon PointIcon = new ImageIcon(".png file");
// Icon SunIcon = new ImageIcon(".png file");
// Icon TimeIcon = new ImageIcon(".png file");

// ASSIGNING A PIECE TO EACH CELL
/*
 * JButton exitButton = new JButton("Exit");
 * controlPanel.add(exitButton);
 * button.setIcon( ); <--- png file?? not too sure
 * exitButton.addActionListener(new ActionListener(){
 * 
 * @Override
 * public void actionPerformed(ActionEvent e) {
 * Game.exit();
 * }
 * button.setIcon( );
 * 
 * });
 */

// PLACING A PIECE ON THE BOARD
/*
 * public void placePiece(int row, int col, Icon pieceIcon) {
 * Jbutton button = boardButtons[row][col];
 * button.setIcon(pieceIron);
 * }
 */

// INTERGRATING WITH GAME LOGIC
// placePiece(A,1, HourglassIcon);