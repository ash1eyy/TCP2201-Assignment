import javax.swing.*;

import java.awt.*;

public class PieceButton extends JButton {
    private Piece piece = null;
    private int x, y;
    private boolean selected = false;
    private Color selectedColour = new Color(255,255,153);

    PieceButton() {}

    public Piece getPiece() {
        return piece;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public boolean getSelected() {
        return selected;
    }

    public void setPiece(Piece piece) {
        this.piece = piece;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setSelected(String player) {
        if (piece != null && piece.getColour() == player) {
            this.selected = true;
            this.setBackground(selectedColour);
        }
        else if (piece == null) {
            this.selected = true;
        }
    }
}
