import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

//for pieces on the board only
public class PieceListener implements ActionListener {
    private PieceButton[][] buttons;
    private Color validMoveColour = new Color(100, 255, 0);

    PieceListener() {}

    @Override
    public void actionPerformed(ActionEvent e) {
        PieceButton clickedButton = (PieceButton) e.getSource();
        GameView view = (GameView) SwingUtilities.windowForComponent(clickedButton);
        GameController controller = view.getController();
        buttons = view.getButtons();

        //if a piece has already been selected
        if (view.getPieceSelected() == true) {
            //originalpiece = newpiece so that newpiece can be assigned to the button that was just clicked
            view.setOriginalPiece(view.getNewPiece());
        }

        view.setNewPiece(clickedButton);
        System.out.println(controller.getPlayer());
        view.getNewPiece().setSelected(controller.getPlayer());

        //DEBUG PURPOSES ONLY
        if (view.getNewPiece().getPiece() != null)
            System.out.println(view.getNewPiece().getPiece() + ", " +
            view.getNewPiece().getPiece().getX() + "," + view.getNewPiece().getPiece().getY() + ", " +
            view.getNewPiece().getPiece().getColour());

        //if a piece has already been selected, attempts to move the piece
        if (view.getPieceSelected() == true) {
            if (controller.getBoard().move(view.getOriginalPiece().getPiece(), view.getNewPiece().getX(), view.getNewPiece().getY())) 
                controller.changeTurns();

            // //checks all the valid moves for the original piece
            // for (ArrayList<Integer> move : view.getOriginalPiece().getPiece().getValidMoves(GameController.getBoard())) {
            //     //if the new piece selected is in one of the valid move spaces of the original piece
            //     //attempt to move the piece
            //     if ((move.get(0) == view.getNewPiece().getPiece().getX() &&
            //         move.get(1) == view.getNewPiece().getPiece().getY())) {
            //         //if the new piece selected is the sun, win the game
            //         if (view.getNewPiece().getPiece() != null &&
            //             view.getNewPiece().getPiece().getPieceName() == "sun") {
            //             JOptionPane.showMessageDialog(view.getBoardPanel(), "Player " + GameController.getTurn() + " wins!");
            //             for (int i = 0; i < 6; i ++) {
            //                 for (int j = 0; j < 7; j++) {
            //                     buttons[i][j].setEnabled(false);
            //                 }
            //             }
            //         }

            //         System.out.println(view.getController().getBoard().getMap());
                    
            //         //we have to actually move the pieces on the board, not just in the gui
            //         view.getController().getBoard().setPiece(move.get(0).intValue(), move.get(1).intValue(), view.getOriginalPiece().getPiece());
            //         view.getController().getBoard().setPiece(view.getOriginalPiece().getPiece().getX(), view.getOriginalPiece().getPiece().getY(), null);

            //         System.out.println(view.getController().getBoard().getMap());
            //     }
            //     //if not, goes to the next iteration of the loop
            // }
            // //after moving the piece, no pieces are selected
            view.setPieceSelected(false);
        }
        //if this is the first time selecting a piece, change pieceSelected value to true
        else {
            view.setPieceSelected(true);
        }

        //highlight valid tiles
        if (view.getNewPiece() != null && view.getPieceSelected() && view.getNewPiece().getSelected()) {
            for (ArrayList<Integer> coords : view.getNewPiece().getPiece().getValidMoves(controller.getBoard())) {
                PieceButton validMoveButton = buttons[coords.get(1)][coords.get(0)];
                validMoveButton.setBackground(validMoveColour);
            }
        }
        else {
            for (int i = 0; i < 6; i++) {
                for (int j = 0; j < 7; j++) {
                    buttons[i][j].setBackground(null);
                    buttons[i][j].setSelected(false);
                }
            }
        }

        view.updatePieces();
    }
}
