import javax.swing.*;

public class Game { // Design Pattern: Facade. Front-facing interface masking more complex code.
    public static void main(String[] args) {
        GameController controller = new GameController();
        // Board board = Board.createInstance();
        // board.init();

        GameView view = new GameView();
        view.setGameController(controller);
        controller.setGameView(view);

        view.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        view.pack();
        view.setLocationRelativeTo(null);
        view.setVisible(true);
        // do game things
    }
}